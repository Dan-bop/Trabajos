/*
 * Copyright (c) 1998, 2021 Oracle and/or its affiliates. All rights reserved.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License v. 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0,
 * or the Eclipse Distribution License v. 1.0 which is available at
 * http://www.eclipse.org/org/documents/edl-v10.php.
 *
 * SPDX-License-Identifier: EPL-2.0 OR BSD-3-Clause
 */

// Contributors:
//     Oracle - initial API and implementation from Oracle TopLink
package org.eclipse.persistence.internal.jpa.parsing;

import org.eclipse.persistence.expressions.Expression;

/**
 * INTERNAL
 * <p><b>Purpose</b>: Superclass for Aggregate Nodes
 * <p><b>Responsibilities</b>:<ul>
 * <li> Apply itself to a query correctly
 * </ul>
 *    @author Jon Driscoll
 *    @since TopLink 5.0
 */
public abstract class AggregateNode extends Node implements AliasableNode {

    private boolean distinct = false;

    /**
     * INTERNAL
     */
    @Override
    public String resolveAttribute() {
        Node arg = getLeft();
        return arg.isDotNode() ? arg.resolveAttribute() : null;
    }

    /**
     * resolveClass: Answer the class associated with my left node.
     */
    @Override
    public Class<?> resolveClass(GenerationContext context) {
        return getLeft().resolveClass(context);
    }

    /**
     * INTERNAL
     * Is this node an Aggregate node
     */
    @Override
    public boolean isAggregateNode() {
        return true;
    }

    /** */
    public boolean usesDistinct() {
        return distinct;
    }

    /** */
    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    /**
     * INTERNAL
     * Return a EclipseLink expression generated using the left node
     */
    @Override
    public Expression generateExpression(GenerationContext context) {
        if (alias == null){
            alias = getAsString();
        }
        Expression aggregateExpr = context.expressionFor(alias);
        if (aggregateExpr == null) {
            Expression arg = getLeft().generateExpression(context);
            if (usesDistinct()) {
                arg = arg.distinct();
            }
            aggregateExpr = addAggregateExression(arg);
            context.addExpression(aggregateExpr, alias);
        }
        return aggregateExpr;
    }

    /**
     * INTERNAL
     */
    protected abstract Expression addAggregateExression(Expression expr);



    @Override
    public boolean isAliasableNode(){
        return true;
    }

}
